export const environment = {
  production: true,
  webAPIUrl: '/'
};
