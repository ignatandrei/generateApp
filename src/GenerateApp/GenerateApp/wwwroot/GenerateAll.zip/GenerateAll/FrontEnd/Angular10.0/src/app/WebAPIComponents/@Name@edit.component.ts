@{
	var angular="@angular";
	var Component = "@Component";
	var dt= Model.FindAfterName("@Name@").Value;
	var nameTable =dt.TableName;
}

import { Component, OnInit } from '@angular/core';

@(Component)({
  selector: 'app-@(nameTable)edit',
  templateUrl: './@(nameTable)edit.component.html',
  styleUrls: ['./@(nameTable)edit.component.css']
})
export class @(nameTable)EditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
